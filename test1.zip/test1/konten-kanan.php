<div class="one_quarter sidebar">
    <div class="sdb_holder">
        <h6>KEPALA SMKN 64 </h6>
        <div class="mediacontainer">
            <a href="profil.php"><img src="images/demo/Foto kepsek.png" alt="" />
            <p>DEWI PUSPITASARI, S.ST.PAR, M.PAR</p></a>
        </div>
    </div>
    <div class="sdb_holder">
        <h6>E-PERPUSTAKAAN</h6>
        <ul class="nospace quickinfo">
            <li class="clear">
                <img src="images/demo/buku2.png"/>  Novel
            </li>
            <li class="clear">
                <img src="images/demo/buku.png"/>  Kamus
            </li>
        </ul>
    </div>
</div>