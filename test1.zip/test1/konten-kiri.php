 <div class="one_quarter first">
    <ul class="nospace">
        <li class="btmspace-15">
            <a href="../test1/pages/gallery.html"><em class="heading">Berita</em>
            <img class="borderedbox" src="images/demo/Pelepasan Kepala Sekolah.png" alt="Pelepasan Kepala Sekolah"/></a>
        </li>
        <li class="btmspace-15">
            <a href="../test1/pages/gallery.html"><em class="heading">Event Sekolah</em>
            <img class="borderedbox" src="images/demo/Artnership.png" alt="Event Artnership"/></a>
            <li class="btmspace-15">
                <a href="#"><em class="heading">PPDB SMKN 64</em>
                <img class="borderedbox" src="images/demo/PPDB SMKN 64.png" alt="PPDB SMKN 64"/>
                </a>
            </li>
            <li>
                <a href="#"><em class="heading">Ujian Tes Mutasi SMKN 64</em>
                <img class="borderedbox" src="images/demo/Ujian Mutasi.png" alt=""/></a>
            </li>
        </li>
    </ul>
</div>
 
    