<div class="one_half">
    <a href=""><h2>Berita Terkini &amp; Event</h2></a>
        <ul class="nospace listing">
            <li class="clear">
                <div class="imgl borderedbox">
                <img src="images/demo/MutasiSmk64.png" alt="" />
                </div>
                  <p class="nospace btmspace-15">
                    <a href="#">Pengumuman Hasil Tes Mutasi Masuk Semester Ganjil TP 2023_2024 Gel-2</a>
                  </p>
                  <p>
                    A. Hasil Berikut saya lampirkan pengumuman Hasil Tes Mutasi
                    Masuk Semester Ganjil TP 2023_2024 Gel-2 SMKN 64 Jakarta<br />
                    B. Persyaratan Berkas Lapor Diri<br />
                    C. Lapor
                    <a href="http://www.os-templates.com/" title="Free Website Templates"></a>
                    <a href="http://www.os-templates.com/template-terms"></a>
                  </p>
                </li>
                <li class="clear">
                  <div class="imgl borderedbox">
                    <img src="images/demo/SidanPrakerin.png" alt="" />
                  </div>
                  <p class="nospace btmspace-15">
                    <a href="#">Sidang Hasil Prakerin Jurusan RPL dan Multimedia SMKN 64 Jakarta</a>
                  </p>
                  <p>
                    smkn64-jkt.sch.id-Jakarta- Tidak terasa sudah 6 bulan
                    berlalu siswa kelas 11 SMKN 64 Jakarta menyelesaikan
                    kegiatan Prakerin (Praktik Kerja Industri).
                  </p>
                </li>
                <li class="clear">
                  <div class="imgl borderedbox">
                    <img src="images/demo/Pengumuman Mutasi.png" alt="" />
                  </div>
                  <p class="nospace btmspace-15">
                    <a href="#"
                      >Pengumuman Mutasi Masuk Peserta Didik SMKN 64 Jakarta
                      Tahun Ajaran 2023/2024 Semester Ganjil TAHAP 2</a
                    >
                  </p>
                  <p>
                    <a href="http://www.os-templates.com/"></a>
                    Dasar : Surat Edaran Kadisdik Nomor e-0037/SE/2023 Tentang
                    Perpindahan (Mutasi),<br />
                    Peserta Didik Semester Ganjil Tahun Pelajaran 2023/2024
                  </p>
                </li>
        </ul>
            <p class="right">
                <a href="#"
                  >Click here to view all of the latest news and events
                  &raquo;</a>
            </p>
</div>