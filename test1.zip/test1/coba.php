<?php
$conn = mysqli_connect("", "", "", "");

if(!$conn){
    die("koneksi gagal:". mysqli_connect_error());
}


?>