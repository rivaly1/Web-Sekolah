<div id="twitter" class="group btmspace-30">
    <div class="one_quarter first center">
        <a href="#">
        <i class="fa fa-instagram fa-3x"></i><br />
        Follow Us On Instagram
        </a>
    </div>
    <div class="three_quarter bold">
        <p>SMKN 64 Jakarta ⋅ SUKSES ( Smart, Unggul, Kreatif, Semangat, Empati, dan Sopan) <br>
        Cek Intagram Kami
        <a href="https://www.instagram.com/smkn64jakarta/">@SMKN 64 Jakarta</a> 
        </p>
    </div>
</div>

<div class="group">
     <h2>Temukan dengan Cepat Apa yang Anda Cari</h2>
        <div class="one_quarter first">
            <ul class="nospace">
                <li><a href="#">Smkn 64 Hebat</a></li>
                <li><a href="#">Smk Pasti Bisa</a></li>
                <li><a href="#">Smk 64 Unggul</a></li>
            </ul>
        </div>
            <div class="one_quarter">
                <ul class="nospace">
                    <li><a href="#">SMKN 64 Jakarta</li>
                    <li><a href="#">LKS 2023</a></li>
                    <li><a href="#">KOPI 64</a></li>
                </ul>
            </div>
            <div class="one_quarter">
              <ul class="nospace">
                <li><a href="#">Informasi Sekolah</a></li>
                <li><a href="#">Event Sekolah</a></li>
                <li><a href="#">Program Sekolah</a></li>
              </ul>
            </div>
            <div class="one_quarter">
              <ul class="nospace">
                <li><a href="#">Registrasi</a></li>
                <li><a href="#">PPDB SMKN 64</a></li>
                <li><a href="#">Informasi PPDB</a></li>
              </ul>
            </div>
</div>